
frmImprove.innerHTML=[  NSB.HeaderBar_jqm14('hdrImprove', 'IMPROVE Score', 'Back', 'arrow-l', 'left', 'Result', 'check', 'right', ' style="" class=" "', '', ''),
  NSB.Checkbox_jqm("chkImprove", '100%', "Active gastro-duodenal ulcer,Bleeding <3 months prior to admission*,Platelet count <50 X 109/L**,Age >85 years,Liver failure with PT >1.5X Normal,Severe renal failure GFR <30 ml/min,ICU/CCU admission,Central line catheter in place,Rheumatic/autoimmune disease,Current cancer,Age 40-84 years,Male,GFR 30-59 ml/min/1.73m2", style="", ' data-mini=true', '', ' ', '', 'left'),
  ].join('');
