
frmMain.innerHTML=[  NSB.HeaderBar_jqm14('hdrMain', 'VTE', 'Feedback', 'home', 'left', 'About', 'info', 'right', ' style="" class=" "', '', ''),
  "<div id='HTMLviewMain_scroller' class=''   style='font-size:13px; font-family:helvetica; font-style:normal; font-weight:normal; color:black; border-style:;' name=''><div id='HTMLviewMain' style='overflow:auto; background-color:transparent; height:auto; min-width:95%;'><b>This app provides guidance on the management of Venous Thromboembolism and is based on the Malaysian VTE Guidelines 2013</b>\u000D\u000A</div></div>",
  NSB.List_jqm14('lstMain', 'ul', 'none', '', 'b', 'Choose One, Risk factors & Prophylaxis, Management, Clinical Tools', '', 'Y,N,N', '', 'class=" "', '100%', false, false, 'false', 'arrow-r', 'false', '', 'false', 'false'),
  "<div id='imgMain' data-nsb-type=image><img src='mshlogo.png'  height=100% width=100% name='imgMain_img' style='' usemap='imgMain_map'></div>",
  ].join('');
