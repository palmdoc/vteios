
frmViewWells.innerHTML=[  NSB.HeaderBar_jqm14('hdrViewWells', 'Info', 'Back', 'arrow-l', 'left', 'Algorithm', 'eye', 'right', ' style="" class=" "', '', ''),
  "<div id='HTMLviewWells_scroller' class=''   style='font-size:13px; font-family:helvetica; font-style:normal; font-weight:normal; color:black; border-style:;' name=''><div id='HTMLviewWells' style='overflow:auto; background-color:transparent; height:auto; min-width:97%;'>Content</div></div>",
  ].join('');
