
frmMX.innerHTML=[  NSB.HeaderBar_jqm14('HdrMX', 'Management', 'Back', 'arrow-l', 'left', '', 'false', 'right', ' style="" class=" "', '', ''),
  NSB.List_jqm14('lstMX', 'ul', 'none', '', 'b', 'Choose One, Anticoagulation,Thrombolytic Therapy,Mechanical Intervention, Investigations for Cancer, Thrombophilia testing,  Follow up, Patient information', '', 'Y,N,N', '', 'class=" "', '100%', true, false, '', 'arrow-r', 'false', '', 'false', 'false'),
  ].join('');
