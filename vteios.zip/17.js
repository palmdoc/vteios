
frmFeedback.innerHTML=[  NSB.HeaderBar_jqm14('hdrFeedback', 'Feedback', 'Back', 'arrow-l', 'left', '', 'false', 'right', ' style="" class=" "', '', ''),
  NSB.List_jqm14('lstFeedback', 'ul', 'ui-li-icon', '', 'b', 'Question or Suggestion?, Email, Website', ',contact.png,website.png ', 'Y,N,N', '', 'class=" "', '100%', false, false, '', 'arrow-r', 'false', '', 'false', 'false'),
  "<div id='Label1' class='' data-nsb-type=Label style='text-align:left; text-shadow:none; font-size:16px; font-family:helvetica; font-style:normal; font-weight:bold; color:black; background-color:transparent; border-style:;border-color:transparent;border-width:1px; ' >This app was coded by Dr. Alan Teh for the MSH</div>",
  ].join('');
