
frmWellsDVT.innerHTML=[  NSB.HeaderBar_jqm14('hdrWellsDVT', 'Wells DVT', 'Back', 'arrow-l', 'left', 'Result', 'check', 'right', ' style="" class=" "', '', ''),
  NSB.Checkbox_jqm("chkWellsDVT", '100%', "Active cancer (rx ongoing or within prev 6 mths or palliative),Paralysis or recent immobilsation of lower extremities, Recently bedridden > 3 days or major surgery within 4 weeks, Localized tenderness along the distrib of deep venous system, Entire leg swollen, Calf swelling 3 cm >asx side (measured 10 cm below tibial tuberosity), Pitting odema greater in the symp leg*, Collateral superficial veins (non-varicose), Previously documented DVT, Alternative diagnosis** to DVT as likely or more likely", style="", ' data-mini=true', '', ' ', '', 'left'),
  ].join('');
