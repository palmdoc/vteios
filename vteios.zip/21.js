
frmCP.innerHTML=[  NSB.HeaderBar_jqm14('HdrCP', 'Risk &amp; Prevention', 'Back', 'arrow-l', 'left', '', 'false', 'right', ' style="" class=" "', '', ''),
  NSB.List_jqm14('lstCP', 'ul', 'none', '', 'b', 'Choose One, Assess the risk for VTE & bleeding, Risk factors for VTE, Risk factors for bleeding, Hospitalised Pts at increased Risk for VTE, Methods of VTE prophylaxis, Monitoring platelet counts, Using VTE prophylaxis in hospitalized pts,Timing of regional anaesthesia/ analgesia,Patient information, Discharge plan', '', 'Y,N,N', '', 'class=" "', '100%', true, false, '', 'arrow-r', 'false', '', 'false', 'false'),
  ].join('');
