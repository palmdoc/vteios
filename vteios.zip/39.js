
frmPicture.innerHTML=[  NSB.HeaderBar_jqm14('hdrAlgorithm', 'Algorithm', 'Back', 'arrow-l', 'left', '', 'false', 'right', ' style="" class=" default"', '', ''),
  "<div id='imgAlgo' data-nsb-type=image><img src=''  height=100% width=100% name='imgAlgo_img' style='' usemap='imgAlgo_map'></div>",
  ].join('');
