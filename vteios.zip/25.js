
frmClinTools.innerHTML=[  NSB.HeaderBar_jqm14('HdrClinTools', 'Clinical Tools', 'Back', 'arrow-l', 'left', '', 'false', 'right', ' style="" class=" "', '', ''),
  NSB.List_jqm14('lstClinTools', 'ul', 'none', '', 'b', 'Choose One, IMPROVE Bleeding Risk, Padua Prediction Score, Well\'s DVT Probability, Well\'s PE Probability', '', 'Y,N,N', '', 'class=" "', '100%', false, false, '', 'arrow-r', 'false', '', 'false', 'false'),
  ].join('');
