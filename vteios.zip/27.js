
frmAnticoag.innerHTML=[  NSB.HeaderBar_jqm14('HdrAnticoag', 'Anticoagulation', 'Back', 'arrow-l', 'left', '', 'false', 'right', ' style="" class=" "', '', ''),
  NSB.List_jqm14('lstAnticoag', 'ul', 'none', '', 'b', 'Choose One, Initial treatment, Duration & Maintenance, Monitoring, Perioperative, Overanticoagulation, Warfarin dosing', '', 'Y,N,N', '', 'class=" "', '100%', false, false, '', 'arrow-r', 'false', '', 'false', 'false'),
  ].join('');
