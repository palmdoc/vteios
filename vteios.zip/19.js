
frmView.innerHTML=[  NSB.HeaderBar_jqm14('hdrView', 'Info', 'Back', 'arrow-l', 'left', '', 'arrow-r', 'none', ' style="" class=" "', '', ''),
  "<div id='HTMLview1_scroller' class=''   style='font-size:13px; font-family:helvetica; font-style:normal; font-weight:normal; color:black; border-style:;' name=''><div id='HTMLview1' style='overflow:auto; background-color:transparent; height:auto; min-width:97%;'><b>HTMLview with scrolling</b></div></div>",
  ].join('');
