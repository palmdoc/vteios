
frmPadua.innerHTML=[  NSB.HeaderBar_jqm14('hdrPadua', 'Padua Score', 'Back', 'arrow-l', 'left', 'Result', 'check', 'right', ' style="" class=" "', '', ''),
  NSB.Checkbox_jqm("chkPadua", '100%', "An active cancer,Previous VTE, Reduced mobility, Already known thrombophilic condition, Recent (<1 month) trauma and/or surgery, Age 70 years and above, Heart and/or respiratory failure, AMI or ischemic stroke, Acute infection and/or rheumatologic disorder, Obesity BMI >30kg/m2,Ongoing hormonal therapy", style="", ' data-mini=true', '', ' ', '', 'left'),
  ].join('');
