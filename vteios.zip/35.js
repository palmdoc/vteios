
frmWellsPE.innerHTML=[  NSB.HeaderBar_jqm14('hdrWellsPE', 'Wells PE', 'Back', 'arrow-l', 'left', 'Result', 'check', 'right', ' style="" class=" "', '', ''),
  NSB.Checkbox_jqm("chkWellsPE", '100%', "Clinical signs & symptoms of DVT (minimum of leg swelling & pain with palpation of deep vein),An alternative diagnosis is less likely than PE,Heart rate greater than 100 beats/min,Immobilization or surgery in previous 4 weeks,Previous DVT/PE, Haemoptysis, Malignancy (on treatment, treated in the last 6 months or palliative)", style="", ' data-mini=true', '', ' ', '', 'left'),
  ].join('');
